"""
Module for currency exchange

This module provides several string parsing functions to implement a simple
currency exchange routine using an online currency service. The primary function
in this module is exchange().

Author: DJ Williams (DWJ)
Date: May 15, 2025
"""

import introcs
APIKEY = '10d5bz2aIsb9EnvsRmmZDNqTF8Y2lLsFranSqpBFZq8e'

def before_space(s):
    """
    Returns the substring of s up to, but not including, the first space.

    Example: before_space('Hello World') returns 'Hello'

    Parameter s: the string to slice
    Precondition: s is a string with at least one space in it
    """
    #enforces precondition
    assert type(s) == str
    assert introcs.count_str(s,' ') >= 1
    #search for the first space
    before = introcs.find_str(s, ' ')
    #return the substring before the first space
    bspace = s[:before]
    return bspace


def after_space(s):
    """
    Returns the substring of s after the first space

    Example: after_space('Hello World') returns 'World'

    Parameter s: the string to slice
    Precondition: s is a string with at least one space in it
    """
    #enforces precondition
    assert type(s) == str
    assert introcs.count_str(s,' ') >= 1
    #search for the first space
    after = introcs.find_str(s, ' ')
    #return the substring before the first space
    aspace = s[after+1:]
    return aspace


def first_inside_quotes(s):
    """
    Returns the first substring of s between two (double) quote characters

    Note that the double quotes must be part of the string.  So "Hello World" is a 
    precondition violation, since there are no double quotes inside the string.

    Example: first_inside_quotes('A "B C" D') returns 'B C'
    Example: first_inside_quotes('A "B C" D "E F" G') returns 'B C', because it only 
    picks the first such substring.

    Parameter s: a string to search
    Precondition: s is a string with at least two (double) quote characters inside
    """
    #enforces precondition
    assert type(s) == str
    assert introcs.count_str(s,'"') >= 2
    #search for the first double quote
    firstq = introcs.find_str(s,'"')
    #search for the second double quote
    secondq = introcs.find_str(s,'"', firstq + 1)
    #return the substring between double quotes
    inside = s[firstq+1:secondq]
    return inside


def get_src(json):
    """
    Returns the src value in the response to a currency query.

    Given a JSON string provided by the web service, this function returns the string
    inside string quotes (") immediately following the substring '"src"'. For example,
    if the json is
    
    '{"success": true, "src": "2 United States Dollars", "dst": "1.772814 Euros", "error": ""}'

    then this function returns '2 United States Dollars' (not '"2 United States Dollars"'). 
    On the other hand if the json is 
    
    '{"success":false,"src":"","dst":"","error":"Source currency code is invalid."}'

    then this function returns the empty string.
    
    The web server does NOT specify the number of spaces after the colons. The JSON
    
    '{"success":true, "src":"2 United States Dollars", "dst":"1.772814 Euros", "error":""}'
    
    is also valid (in addition to the examples above).

    Parameter json: a json string to parse
    Precondition: json a string provided by the web service (ONLY enforce the type)
    """
    #enforces precondition
    assert type(json) == str
    #find src and the colon
    start = introcs.find_str(json, '"src"')
    colon = introcs.find_str(json, ':', start)
    #find the first double quote after src
    firstq = introcs.find_str(json,'"', colon)
    #find the second double quote after src
    secondq = introcs.find_str(json,'"', firstq + 1)
    #return the result
    src = json[firstq+1:secondq]
    return src


def get_dst(json):
    """
    Returns the dst value in the response to a currency query.

    Given a JSON string provided by the web service, this function returns the string
    inside string quotes (") immediately following the substring '"dst"'. For example,
    if the json is
    
    '{"success": true, "src": "2 United States Dollars", "dst": "1.772814 Euros", "error": ""}'

    then this function returns '1.772814 Euros' (not '"1.772814 Euros"'). On the other
    hand if the json is 
    
    '{"success":false,"src":"","dst":"","error":"Source currency code is invalid."}'

    then this function returns the empty string.

    The web server does NOT specify the number of spaces after the colons. The JSON
    
    '{"success":true, "src":"2 United States Dollars", "dst":"1.772814 Euros", "error":""}'
    
    is also valid (in addition to the examples above).

    Parameter json: a json string to parse
    Precondition: json a string provided by the web service (ONLY enforce the type)
    """
    #enforces precondition
    assert type(json) == str
    #find src and the colon
    start = introcs.find_str(json, '"dst"')
    colon = introcs.find_str(json, ':', start)
    #find the first double quote after dst
    firstq = introcs.find_str(json,'"', colon)
    #find the second double quote after dst
    secondq = introcs.find_str(json,'"', firstq + 1)
    #return the result
    dst = json[firstq+1:secondq]
    return dst


def has_error(json):
    """
    Returns True if the response to a currency query encountered an error.

    Given a JSON string provided by the web service, this function returns True if the
    query failed and there is an error message. For example, if the json is
    
    '{"success":false,"src":"","dst":"","error":"Source currency code is invalid."}'

    then this function returns True (It does NOT return the error message 
    'Source currency code is invalid'). On the other hand if the json is 
    
    '{"success": true, "src": "2 United States Dollars", "dst": "1.772814 Euros", "error": ""}'

    then this function returns False.

    The web server does NOT specify the number of spaces after the colons. The JSON
    
    '{"success":true, "src":"2 United States Dollars", "dst":"1.772814 Euros", "error":""}'
    
    is also valid (in addition to the examples above).

    Parameter json: a json string to parse
    Precondition: json a string provided by the web service (ONLY enforce the type)
    """


def has_error(json):
    """
    Returns True if the response to a currency query encountered an error.

    Given a JSON string provided by the web service, this function returns True if the
    query failed and there is an error message. For example, if the json is
    
    '{"success":false,"src":"","dst":"","error":"Source currency code is invalid."}'

    then this function returns True (It does NOT return the error message 
    'Source currency code is invalid'). On the other hand if the json is 
    
    '{"success": true, "src": "2 United States Dollars", "dst": "1.772814 Euros", "error": ""}'

    then this function returns False.

    The web server does NOT specify the number of spaces after the colons. The JSON
    
    '{"success":true, "src":"2 United States Dollars", "dst":"1.772814 Euros", "error":""}'
    
    is also valid (in addition to the examples above).

    Parameter json: a json string to parse
    Precondition: json a string provided by the web service (ONLY enforce the type)
    """
    #asserts the precondition
    assert type(json) == str
    #find error
    start = introcs.find_str(json, '"error"')
    colon = introcs.find_str(json, ':', start)
    #find the first double quote after error
    firstq = introcs.find_str(json,'"', colon)
    #find the second double quote after error
    secondq = introcs.find_str(json,'"', firstq + 1)
    #return the result
    error = json[firstq+1:secondq]
    return error != ''


def service_response(src,dst,amt):
    """
    Returns a JSON string that is a response to a currency query.

    A currency query converts amt money in currency src to the currency dst. The response 
    should be a string of the form

    '{"success": true, "src": "<src-amount>", "dst": "<dst-amount>", "error": ""}'

    where the values src-amount and dst-amount contain the value and name for the src 
    and dst currencies, respectively. If the query is invalid, both src-amount and 
    dst-amount will be empty, and the error message will not be empty.

    There may or may not be spaces after the colon.  To test this function, you should
    choose specific examples from your web browser.

    Parameter src: the currency on hand
    Precondition: src is a nonempty string with only letters

    Parameter dst: the currency to convert to
    Precondition: dst is a nonempty string with only letters

    Parameter amt: amount of currency to convert
    Precondition: amt is a float or int
    """
    assert type(src) == str and src != '' and +\
    all('A' <= c <= 'Z' or 'a' <= c <= 'z' for c in src)
    assert type(dst) == str and dst != '' and +\
    all('A' <= c <= 'Z' or 'a' <= c <= 'z' for c in dst)
    assert type(amt) == float or type(amt) == int

    start = 'https://ecpyfac.ecornell.com/python/currency/fixed?'
    addition = 'src='+src+'&dst='+dst+'&amt='+repr(amt)+'&key='+APIKEY
    full = start + addition
    result = introcs.urlread(full)
    return result 


def iscurrency(currency):
    """
    Returns True if currency is a valid (3 letter code for a) currency.

    It returns False otherwise.

    Parameter currency: the currency code to verify
    Precondition: currency is a nonempty string with only letters
    """
    # Assert precondition
    assert type(currency) == str and currency != '' and +\
    all('A' <= c <= 'Z' or 'a' <= c <= 'z' for c in currency)

    # Send a test conversion request using the currency as the source
    response = service_response(currency, 'USD', 1.0)

    # Use the has_error to check for an error
    return not has_error(response)


def exchange(src,dst,amt):
    """
    Returns the amount of currency received in the given exchange.

    In this exchange, the user is changing amt money in currency src to the currency 
    dst. The value returned represents the amount in currency currency_to.

    The value returned has type float.

    Parameter src: the currency on hand
    Precondition: src is a string for a valid currency code

    Parameter dst: the currency to convert to
    Precondition: dst is a string for a valid currency code

    Parameter amt: amount of currency to convert
    Precondition: amt is a float or int
    """
    #Retrieves the JSON response string from the web service
    json = service_response(src, dst, amt)

    #Extract the destination string
    dst_str = get_dst(json)

    # Step 3: Get the numeric part before the space
    value_str = before_space(dst_str)

    # Step 4: Convert to float and return
    return float(value_str)





    