"""
User interface for module currency

When run as a script, this module prompts the user for two currencies and amount.
It prints out the result of converting the first currency to the second.

Author: DJ Williams (DWJ)
Date: May 15, 2025
"""

import currency
src = input('3-letter code for original currency: ')
dst = input('3-letter code for the new currency: ')
amt = input('Amount of the original currency: ')

# Convert amount to float
amt = float(amt)
# Perform the currency exchange
result = currency.exchange(src, dst, amt)
# Round to three decimal places
rounded = round(result, 3)
# Print the result using the exact required wording and formatting
print(f"You can exchange {amt} {src} for {rounded} {dst}.")