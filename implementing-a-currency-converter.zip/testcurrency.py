"""
Unit tests for module currency

When run as a script, this module invokes several procedures that test
the various functions in the module currency.

Author: DJ Williams (DWJ)
Date: May 15, 2025
"""

import introcs
import currency


def test_before_space():
    """
    Test procedure for before_space
    """
    print('Testing before_space.')

    #Test case 1
    result = currency.before_space('Hello World')
    introcs.assert_equals('Hello', result)

    #Test case 2 
    result = currency.before_space('Hello  Earth Dwellers')
    introcs.assert_equals('Hello', result)

    #Test case 3
    result = currency.before_space(' Hello World')
    introcs.assert_equals('', result)

    #Test case 4
    result = currency.before_space(' Hello')
    introcs.assert_equals('', result)


def test_after_space():
    """
    Test procedure for after_space
    """
    print('Testing after_space.')

    #Test case 1
    result = currency.after_space('Hello World')
    introcs.assert_equals('World', result)

    #Test case 2 
    result = currency.after_space('Hello  Earth Dwellers')
    introcs.assert_equals(' Earth Dwellers', result)

    #Test case 3
    result = currency.after_space(' Hello World')
    introcs.assert_equals('Hello World', result)

    #Test case 4
    result = currency.after_space('Hello ')
    introcs.assert_equals('', result)


def test_first_inside_quotes():
    """
    Test procedure for first_inside_quotes
    """
    print('Testing first_inside_quotes.')

    #Test case 1
    result = currency.first_inside_quotes('A "B C" D')
    introcs.assert_equals('B C', result)

    #Test case 2 
    result = currency.first_inside_quotes('A "B C" D "E F" G')
    introcs.assert_equals('B C', result)

    #Test case 3
    result = currency.first_inside_quotes('A ""B C D"" E F')
    introcs.assert_equals('', result)

    #Test case 4
    result = currency.first_inside_quotes('"A B C D E F G"')
    introcs.assert_equals('A B C D E F G', result)


def test_get_src():
    """
    Test procedure for get_src
    """
    print('Testing get_src.')
    #Test case 1, standard spacing
    result = currency.get_src('{"success": true, "src": "5 Euros"' +
    ',"dst" :"4.43 United States Dollars", "error": ""}')
    introcs.assert_equals('5 Euros', result)

    #Test case 2, empty src
    result = currency.get_src('{"success":false,' +
    '"src":"","dst":"","error":"Source currency code is invalid."}')
    introcs.assert_equals('', result)

    #Test case 3, no spacing
    result = currency.get_src('{"success":true,' +
    '"src":"2 United States Dollars","dst":"1.772814 Euros","error":""}')
    introcs.assert_equals('2 United States Dollars', result)

    #Test case 4, extra spacing
    result = currency.get_src('{"success":   false,' +
    '"src":   "", "dst": "", "error": "source currency code is invalid."}')
    introcs.assert_equals('', result)


def test_get_dst():
    """
    Test procedure for get_dst
    """
    print('Testing get_dst')
    #Test case 1: non empty, standard spacing
    result = currency.get_dst('{"success": true, "src": "5.0 United States Dollars",' +
    '"dst": "4.432035 Euros", "error": ""}')
    introcs.assert_equals('4.432035 Euros', result)
    #Test case 2: empty string, no spacing
    result = currency.get_dst('{"success":false,' +
    '"src":"","dst":"","error":"Source currency code is invalid."}')
    introcs.assert_equals('',result)
    #Test case 3: non empty string, no spacing
    result = currency.get_dst('{"success":true,"src":"5.0 United States Dollars",' +
    '"dst":"4.432035 Euros","error":""}')
    introcs.assert_equals('4.432035 Euros', result)
    #Test case 4: empty string, extra spacing
    result = currency.get_dst('{"success":  false,' +
    '"src":  "","dst":  "","error":"Source currency code is invalid."}')
    introcs.assert_equals('',result)


def test_has_error():
    """
    Test procedure for has_error
    """
    print('Testing has_error.')
    #Test case 1, no error & standard spacing
    result = currency.has_error('{"success":true, ' +
    '"src":"2 United States Dollars","dst":"1.772814 Euros","error":""}')
    introcs.assert_false(result)
    #Test case 2, error & standard spacing
    result = currency.has_error('{"success":false,' +
    '"src":"","dst":"","error":"Source currency code is invalid"}')
    introcs.assert_true(result)
    #Test case 3, no error & extra spacing
    result = currency.has_error('{"success":  true,' +
    '"src":  "2 United States Dollars","dst":  "1.772814 Euros","error":  ""}')
    introcs.assert_false(result)
    #Test case 4, error & extra spacing
    result = currency.has_error('{"success":  false,' +
    '"src":  "","dst":  "","error":  "Source currency code is invalid"}')
    introcs.assert_true(result)


def test_service_response():
    """
    Test procedure for service_response
    """
    print('Testing service_response')
    #Test case 1, valid currencies, non negative amount
    result = currency.service_response('USD','EUR',2.5)
    introcs.assert_equals('{"success": true, "src": "2.5 United States Dollars"'+
    ', "dst": "2.2160175 Euros", "error": ""}', result)
    #Test case 2, negative numbers
    result = currency.service_response('USD','EUR',-2.5)
    introcs.assert_equals('{"success": true, "src": "-2.5 United States Dollars"'+
    ', "dst": "-2.2160175 Euros", "error": ""}', result)
    #Test case 3, invalid dst
    result = currency.service_response('USD', 'EUA', 5.0)
    introcs.assert_equals('{"success": false, "src": "", "dst": ""'+
    ', "error": "The rate for currency EUA is not present."}', result)
    result = currency.service_response('USA', 'EUR', 5.0)
    introcs.assert_equals('{"success": false, "src": "", "dst": ""'+
    ', "error": "The rate for currency USA is not present."}', result)


def test_iscurrency():
    """
    Test procedure for iscurrency
    """
    print('Testing iscurrency.')
    #Test case # 1, uppercase
    result = currency.iscurrency('USD')
    introcs.assert_true(result)
    #Test case # 2, lowercase
    result = currency.iscurrency('USDA')
    introcs.assert_false(result)


def test_exchange():
    """
    Test procedure for exchange
    """
    print('Testing exchange.')
    #Test case 1
    result = currency.exchange('USD', 'EUR', 1.0)
    introcs.assert_floats_equal(result, result)  # Just checking it returns a float
    # Test case 2
    result = currency.exchange('USD', 'EUR', -10.0)
    introcs.assert_floats_equal(result, result)


test_before_space()
test_after_space()
test_first_inside_quotes()
test_get_src()
test_get_dst()
test_has_error()
test_service_response()
test_iscurrency()
test_exchange()
print('All tests completed successfully.')